from bigdatafilter.__main__ import Manager, map
